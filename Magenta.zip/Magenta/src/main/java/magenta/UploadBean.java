package magenta;


import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.mysql.jdbc.Statement;
import com.oreilly.servlet.MultipartRequest;




public class UploadBean extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String path = "C:/windows/temp";
	java.io.PrintWriter out = null;
	Document doc = null;
	Connection conn = null;
	java.sql.Statement stmt = null;
	String s = null;

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {


		try {
			CreateConnection();
			} 
			catch (InstantiationException e) {e.printStackTrace();}
			catch (IllegalAccessException e) {e.printStackTrace();}
			catch (ClassNotFoundException e) {e.printStackTrace();}
			catch (SQLException e) {e.printStackTrace();} 
			catch (NamingException e) {e.printStackTrace();} 




	//SaveFile(request);

	try {
	ParseFile(request);
	}
	catch (ParserConfigurationException e1) {e1.printStackTrace();}
	catch (SAXException e1) {e1.printStackTrace();}

	try {
	setCities((Element) doc.getDocumentElement().getElementsByTagName("Cities").item(0));
	} catch (SQLException e) {e.printStackTrace();}

	try {
	setDistance((Element) doc.getDocumentElement().getElementsByTagName("Distances").item(0));
	} catch (SQLException e) {e.printStackTrace();}

	CloseConnection();

	response.setContentType("text/html;charset=Windows-1251");
	request.setCharacterEncoding("Cp1251"); 
	out = response.getWriter();
	out.println("<html>");
	out.println("<body>");
	out.println("<a href='index.jsp'>Back to main</a>");
	out.println("</body>");
	out.println("</html>");
	out.close();
	}
	
	public void SaveFile(HttpServletRequest request) throws IOException{
	
		File dir = new File(request.getSession().getServletContext().getRealPath("WEB-INF/"));
		MultipartRequest mpr = new MultipartRequest(request, path);
		//out.println("<b>Read/Parse file...</b><br>");
		
		
	}
	
	public void ParseFile(HttpServletRequest request) throws ParserConfigurationException, SAXException, IOException{
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		doc = db.parse(request.getRealPath("./").concat("cities.xml"));
		

	}
	
	public void CreateConnection() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, NamingException{
	
		Context initCtx = new InitialContext();
		//Context envCtx = (Context) initCtx.lookup("java:comp/env");
		DataSource ds = (DataSource)initCtx.lookup("java:/jdbc/datasources/magenta/datasource/test-distance-calculator");
		 if (ds != null) {
		        conn = ds.getConnection();
		        stmt = conn.createStatement();
		        stmt.executeUpdate("DROP TABLE IF EXISTS City, Distance");
			    stmt.executeUpdate("CREATE TABLE City (id INTEGER NOT NULL PRIMARY KEY, Name VARCHAR(100), Latitude FLOAT, Longitude FLOAT)");
			    stmt.executeUpdate("CREATE TABLE Distance (id_fromCity INTEGER, id_toCity INTEGER, distance LONG)");
	/*			    
		        Liquibase liquibase = null;
		        try {
		            Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(new JdbcConnection(conn));
		            liquibase = new Liquibase("C:/liquibase/change_log.xml", new FileSystemResourceAccessor(), database);
		            liquibase.update("");
		        } finally {
		            if (conn != null) {
		                try {
		                	conn.rollback();
		                	conn.close();
		                } catch (SQLException e) {
		                    //nothing to do
		                }
		            }
		        }
		*/
		 }
	}

	public void setCities(Element node) throws SQLException{
		stmt = conn.createStatement();
		if (node.hasChildNodes()) {
			NodeList children = node.getChildNodes();
			
			for (int i = 0; i < children.getLength(); i++) {
				if (children.item(i).getNodeType() == Node.ELEMENT_NODE) {
				Element child = (Element) children.item(i);
				//System.out.println("< " + child.getNodeName() + " " + child.getAttribute("name") + ">");
				
				stmt.executeUpdate("Insert into city (id,Name,Latitude,Longitude)  values('" + 
						       child.getAttribute("id") + "','" + 
							 child.getAttribute("name") + "','" +
						 child.getAttribute("Latitude") + "','" +
						 child.getAttribute("Longitude") + "')");
				/*
			 out.println("Insert into city values ('" + 
					 			 child.getAttribute("id") + "'" + 
					 		 child.getAttribute("name") + "','" +
					 	 child.getAttribute("Latitude") + "','" +
					 	 child.getAttribute("Longitude") + "')<br>");
					 	 */
				}
			}
		}	
	}
	
	
	public void setDistance(Element node) throws SQLException{
		stmt = conn.createStatement();
		if (node.hasChildNodes()) {
			NodeList children = node.getChildNodes();
			
			for (int i = 0; i < children.getLength(); i++) {
				if (children.item(i).getNodeType() == Node.ELEMENT_NODE) {
				Element child = (Element) children.item(i);
				
				stmt.executeUpdate("Insert into distance (id_fromCity,id_toCity,distance)  values('" + 
						child.getAttribute("FromCity") + "','" + 
						  child.getAttribute("ToCity") + "','" +
					         child.getAttribute("Dis") + "')" );
				/*
				out.println("Insert into distance values('" + 
						child.getAttribute("FromCity") + "','" + 
						  child.getAttribute("ToCity") + "','" +
					         child.getAttribute("Dis") + "')<br>" );
					         */
				}
			}
		}
	}
	
	public void CloseConnection(){
		
		if (conn != null)
        {
            try
            {
                conn.close ();
                //out.println ("<b>Database connection closed...</b><br>");
            }
            catch (Exception e){}
        }
	}

}
