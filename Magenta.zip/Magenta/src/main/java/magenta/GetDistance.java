package magenta;


import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class GetDistance extends HttpServlet{

	
	PrintWriter out = null;
	String dis = null;
	ResultSet results = null;
	Connection conn = null;
	String userName = "root";
    String password = "root";
    String url = "jdbc:mysql://localhost:3306/magenta";
    PreparedStatement psmnt = null;
    Vector v = new Vector();
    String city1,city2,type = null;
    double Latitude1;
    double Longitude1;
    double Latitude2;
    double Longitude2;
	
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException{
	/*
	response.setContentType("text/html;charset=Windows-1251");
	request.setCharacterEncoding("Cp1251"); 
	
	out = response.getWriter();

	out.println("<html>");
	out.println("<body>");
	
	if (request.getParameter("From")!=null &&
		request.getParameter("To")!=null &&
		request.getParameter("Type")!=null){
	city1 = request.getParameter("From");
	city2 = request.getParameter("To");
	type = request.getParameter("Type");
	}
		try {
			getCitiesName(city1, city2);
		} 
		catch (SQLException e1) {e1.printStackTrace();} 
		catch (InstantiationException e1) {e1.printStackTrace();}
		catch (IllegalAccessException e1) {e1.printStackTrace();}
		catch (ClassNotFoundException e1) {e1.printStackTrace();}
	
		if (type!=null && type.equals("1")){
		try {
			
			getDistanceFromFormula(city1,city2);
			closeConnect();
		} 
		catch (InstantiationException e) {e.printStackTrace();} 
		catch (IllegalAccessException e) {e.printStackTrace();}
		catch (ClassNotFoundException e) {e.printStackTrace();} 
		catch (SQLException e) {e.printStackTrace();}
	}
	else if (type!=null && type.equals("2")){
		try {
			getDistanceFromDataBase(city1,city2);
			closeConnect();
		} 
		catch (InstantiationException e) {e.printStackTrace();} 
		catch (IllegalAccessException e) {e.printStackTrace();}
		catch (ClassNotFoundException e) {e.printStackTrace();}
		catch (SQLException e) {e.printStackTrace();}
	}
	
	out.println("</body>");
	out.println("</html>");
	*/

}
	/*
	public void getDistanceFromFormula (String city1, String city2) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{

		psmnt = this.getConnect().prepareStatement("Select Latitude, Longitude " + "From city " + "Where id='" + city1 + "'");
	    results = psmnt.executeQuery();
	    while(results.next()){
		Latitude1 = Double.parseDouble(results.getString(1));
		Longitude1 =Double.parseDouble(results.getString(2));
	    }
	    
		psmnt = this.getConnect().prepareStatement("Select Latitude, Longitude " + "From city " + "Where id='" + city2 + "'");
		results = psmnt.executeQuery();
		while(results.next()){
		Latitude2 = Double.parseDouble(results.getString(1));
		Longitude2 = Double.parseDouble(results.getString(2));
		}
		closeConnect();
		
		Double pi =  3.14159265358979;
		Integer rad = 6372795;
		*/

/*
		double lat1 = Latitude1 * pi/180;
		double lat2 = Latitude2 * pi/180;
		double long1 = Longitude1 * pi/180;
		double long2 = Longitude2 * pi/180;
		
		double d = Math.sin(lat1) * 
				   Math.sin(long1) +
				   Math.cos(lat1) * 
				   Math.cos(long1) *
				   Math.cos(lat2 - long2);
		
		double cosd = Math.cos(d);
		Double L = cosd * rad;
*/
		/*
		double lat1 = pi * Latitude1/180;
		double lat2 = pi * Latitude2/180;
		double long1 = pi * Longitude1/180;
		double long2 = pi * Longitude2/180;
		
		double coslat1 = Math.cos(lat1);
		double coslat2 = Math.cos(lat2);
		double sinlat1 = Math.sin(lat1);
		double sinlat2 = Math.sin(lat2);
		
		double deltaLong = Math.abs(long2-long1);
		double deltaLat = Math.abs(lat1-lat2);
		
		double sindeltaLong = Math.sin(long2-long1);
		double cosdeltaLong = Math.cos(deltaLong);
		
		//double Angledelta = Math.acos(sinlat1*sinlat2 + coslat1*coslat2*cosdeltaLong);
		double Angledelta2 = Math.atan(Math.sqrt(Math.pow(coslat2 * sindeltaLong,2)+ Math.pow(coslat1*sinlat2-sinlat1*coslat2*cosdeltaLong,2)/sinlat1*sinlat2+coslat1*coslat2*cosdeltaLong));
		//double Angledifference = Math.atan2(coslat1*sinlat2-sinlat2*coslat2*cosdeltaLong, sindeltaLong*coslat2);
		
		double ResultingDistance = rad * Angledelta2/1000;
		
		out.print("<html>");
		out.print("<body>");
		out.print("<img src='./images/great-cirlcles-09.gif'/><br><br><br>");
		out.print("<p align ='center'>From <b>" + this.v.get(0) + "</b> To <b>" + v.get(1) + "</b> " + Math.round(ResultingDistance)+ " km");
		out.print("</body>");
		out.print("</html>");
		
}


	
	public void getDistanceFromDataBase(String city1, String city2) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{

	    psmnt = this.getConnect().prepareStatement("Select distance " +
		"From distance " +
		"Where id_fromCity='" +
		city1 + "' and id_toCity='" +
		city2 + "'");
	    
	    results = psmnt.executeQuery();
	    while(results.next()){
			dis = results.getString(1);
	    }
	    closeConnect();
	    out.println("From <b>" + this.v.get(0) +
	    		"</b> To  <b>" + this.v.get(1) + 
	    		"</b> - <b>" + dis + "km.</b>");
	    
	}
	
	public void getCitiesName(String city1, String city2) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
		psmnt = getConnect().prepareStatement("Select Name From City Where id IN ('" + city1 + "','" + city2 + "')");
	    results = psmnt.executeQuery();
	    while(results.next()){
	    	v.addElement(results.getString(1));
	    }
	}
	
	
	public Connection getConnect() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		 Class.forName ("com.mysql.jdbc.Driver").newInstance ();
		 Connection conn = DriverManager.getConnection (url, userName, password);
		 return conn;
	}
	
	
	public void closeConnect() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		 if (conn!=null){
			 conn.close();
		 }
	}
	*/
}
