package magenta;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;




@Path(value="calculate")
public class Calculate {
	

	@Context 
	HttpServletResponse response;
	
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getDistance(@QueryParam("From") String from, @QueryParam("To") String to, @QueryParam("Type") String type) throws IOException, SQLException, NamingException{
		//System.out.println("!!!!!!!!!!!!!!" + from + to + type);
		String result = "";
		String query = null;
		java.sql.PreparedStatement psmnt = null;
		ResultSet results = null;
		String f = null;
		String t = null;
	    double Latitude1 = 0;
	    double Longitude1 = 0;
	    double Latitude2 = 0;
	    double Longitude2 = 0;
		String link = "<br><br><a href='/Magenta/calculate.jsp'>Back</a>  <a href='/Magenta/index.jsp'>Main</a>";
		
		//response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
	if(from!="" & to!="" & type.equals("2")){
		query = "select (select name from city c where c.id = d.id_fromCity) as c1, (select name from city c where c.id = d.id_toCity) as c2, distance from distance d where d.id_fromCity ="+from+" and d.id_toCity="+to;
		psmnt = (java.sql.PreparedStatement) this.getCoonect().prepareStatement(query);
		String distance = null;
		results = psmnt.executeQuery();
		while (results.next()){
			if (results.getRow()==1){
			f = results.getString(1);
			t = results.getString(2);
			distance = results.getString(3);
				if (distance==""){
					throw new NullPointerException("The distance for id_fromCity="+from+" and idtoCity="+to+" IS NULL"); 
				}
			}
		}
		results.close();
		psmnt.close();
		this.getCoonect().close();
		result = "Result from DataBase: "+f+" - "+t+" "+ distance+ " km" + link;
	}

	if(from!="" & to!="" & type.equals("1")){
		query = "select id, name, Latitude, Longitude from city where id in ("+from+","+to+")";
		psmnt = (java.sql.PreparedStatement) this.getCoonect().prepareStatement(query);
		results = psmnt.executeQuery();
		while (results.next()){
			if (results.getString(1).equals(from)){
				f = results.getString(2);
				Latitude1 = Double.parseDouble(results.getString(3));
				Longitude1 =Double.parseDouble(results.getString(4));
			}
			if (results.getString(1).equals(to)){
				t = results.getString(2);
				Latitude2 = Double.parseDouble(results.getString(3));
				Longitude2 =Double.parseDouble(results.getString(4));
			}
		}
		results.close();
		psmnt.close();
		this.getCoonect().close();

		//formula for distance calculation from internet  
		//L = R * acos(sin(lat1) * sin(lat2) + cos(lat1) * cos(lat2) * cos(lon1 - lon2))
		Double pi =  3.14159265358979;
		Integer rad = 6371;
		
		double lat1 = Latitude1 * pi/180;
		double lat2 = Latitude2 * pi/180;
		double long1 = Longitude1 * pi/180;
		double long2 = Longitude2 * pi/180;
		double L = Math.acos(Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1) * Math.cos(lat2) + Math.cos(long1-long2))*rad;
		result = "Result from formula: "+f+" - "+t+" "+ Math.round(L)+ " km" + link;

	}
	
	return result;
	}
	
	
	Connection getCoonect() throws NamingException, SQLException{
		javax.naming.Context initCtx = new InitialContext();
		DataSource ds = (DataSource)initCtx.lookup("java:/jdbc/datasources/magenta/datasource/test-distance-calculator");
		Connection conn = ds.getConnection();
		return conn;
	}
	

}
